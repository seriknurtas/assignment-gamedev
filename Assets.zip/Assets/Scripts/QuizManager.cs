﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuizManager : MonoBehaviour
{
    public int score = 0;
    public TMP_Text ScoreTxt;

    public List<QuestionAndAnswers> QnA_Level1; 
    public List<QuestionAndAnswers> QnA_Level2;

    private List<QuestionAndAnswers> currentQnA;
    public Image WordImage;
    public TMP_Text ResultTxt_Word;

    public GameObject[] options;
    public int currentQuestion;

    public Text QuestionTxt;
    public TMP_Text ResultTxt;
    public int level = 1; 

    public List<WordQuestion> WordQuestions; 
    public GameObject LetterButtonPrefab; 
    public Transform LettersParent; 
    public TMP_Text PlayerAnswerTxt; 
    public GameObject MainCanvas;      
    public GameObject WordGameCanvas;   

    private string correctWord;
    private string playerAnswer = "";



    private void Start()
    {
        ResultTxt.gameObject.SetActive(false);
        score = 0;
        UpdateScore();
        level = 1;
        currentQnA = new List<QuestionAndAnswers>(QnA_Level1); 
        generateQuestion();
    }
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
            Debug.Log("Game Quit via ESC");
        }
    }

    void UpdateScore()
    {
        ScoreTxt.text = "Score: " + score;
    }

    IEnumerator HideResultText()
    {
        yield return new WaitForSeconds(0.6f);
        ResultTxt.gameObject.SetActive(false);
    }
    public void SubmitWord()
    {
        if (playerAnswer == correctWord)
        {
            score++;
            UpdateScore();

            ResultTxt_Word.text = "Correct!";
            ResultTxt_Word.color = Color.green;
            ResultTxt_Word.gameObject.SetActive(true);
            StartCoroutine(HideTextAfterDelay(ResultTxt_Word, 0.6f));

            WordQuestions.RemoveAll(wq => wq.Word.ToUpper() == correctWord);

            if (WordQuestions.Count > 0)
            {
                generateWordGame();
            }
            else
            {
                ResultTxt_Word.text = "All done!";
            }
        }
        else
        {
            ResultTxt_Word.text = "Wrong! Try Again!";
            ResultTxt_Word.color = Color.red;
            ResultTxt_Word.gameObject.SetActive(true);
            StartCoroutine(HideTextAfterDelay(ResultTxt_Word, 0.6f));

        }
    }
    IEnumerator HideTextAfterDelay(TMP_Text textElement, float delay)
    {
        yield return new WaitForSeconds(delay);
        textElement.gameObject.SetActive(false);
    }


    public void Correct()
    {
        score++;
        UpdateScore();

        ResultTxt.gameObject.SetActive(true);
        ResultTxt.text = "Correct!";
        ResultTxt.color = Color.green;
        StartCoroutine(HideResultText());

        currentQnA.RemoveAt(currentQuestion);

        if (currentQnA.Count > 0)
        {
            generateQuestion();
        }
        else
        {
            if (level == 1)
            {
                
                level = 2;
                currentQnA = new List<QuestionAndAnswers>(QnA_Level2);
                generateQuestion();
            }
            else if (level == 2)
            {
                level = 3;
                generateWordGame();
            }
            else
            {
                QuestionTxt.text = "You won";
                ResultTxt.text = "Thanks for playing!";
                ResultTxt.color = Color.green;
                ResultTxt.gameObject.SetActive(true);

                StartCoroutine(ExitGameAfterDelay(2f));
            }

        }
    }
    IEnumerator ExitGameAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        Application.Quit();
        Debug.Log("Game Finished and Quit");
    }



    public void Wrong()
    {
        ResultTxt.gameObject.SetActive(true);
        ResultTxt.text = "Wrong! Try Again!";
        ResultTxt.color = Color.red;
        StartCoroutine(HideResultText());
    }
    void Shuffle(List<char> list)
    {
        for (int i = 0; i < list.Count; i++)
        {
            char temp = list[i];
            int randomIndex = Random.Range(i, list.Count);
            list[i] = list[randomIndex];
            list[randomIndex] = temp;
        }
    }
    void SelectLetter(GameObject letterButton)
    {
        string letter = letterButton.transform.GetChild(0).GetComponent<TMP_Text>().text;
        playerAnswer += letter;
        PlayerAnswerTxt.text = playerAnswer;

        letterButton.SetActive(false);
    }
    void CheckPlayerAnswer()
    {
        if (playerAnswer == correctWord)
        {
            ResultTxt.gameObject.SetActive(true);
            ResultTxt.text = "Correct!";
            StartCoroutine(HideResultText());

           
            Debug.Log("You completed the word game!");
        }
        else
        {
            ResultTxt.gameObject.SetActive(true);
            ResultTxt.text = "Wrong! Try Again!";
            StartCoroutine(HideResultText());
        }
    }
    public void ClearPlayerAnswer()
    {
        playerAnswer = "";
        PlayerAnswerTxt.text = "";

        foreach (Transform letter in LettersParent)
        {
            letter.gameObject.SetActive(true);
        }
    }
    void ClearLetters()
    {
        foreach (Transform child in LettersParent)
        {
            Destroy(child.gameObject);
        }
    }

    void generateWordGame()
    {
        int randomIndex = Random.Range(0, WordQuestions.Count);
        WordQuestion wordQ = WordQuestions[randomIndex];
        correctWord = wordQ.Word.ToUpper();
        WordImage.sprite = wordQ.AssociatedImage;


        MainCanvas.SetActive(false);         
        WordGameCanvas.SetActive(true);      

        ClearLetters();
        PlayerAnswerTxt.text = "";
        playerAnswer = "";

        correctWord = WordQuestions[randomIndex].Word.ToUpper();

        List<char> letters = new List<char>(correctWord.ToCharArray());

        string extraLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        int extraCount = 3; 

        for (int i = 0; i < extraCount; i++)
        {
            char randomExtra = extraLetters[Random.Range(0, extraLetters.Length)];
            letters.Add(randomExtra);
        }

        Shuffle(letters);

        foreach (char letter in letters)
        {
            GameObject letterBtn = Instantiate(LetterButtonPrefab, LettersParent);
            letterBtn.transform.GetChild(0).GetComponent<TMP_Text>().text = letter.ToString();
            letterBtn.GetComponent<Button>().onClick.AddListener(() => SelectLetter(letterBtn));
        }
    }


    void SetAnswers()
    {
        for (int i = 0; i < options.Length; i++)
        {
            options[i].SetActive(false);
        }

        if (level == 1)
        {
            for (int i = 0; i < options.Length && i < currentQnA[currentQuestion].Answers.Length; i++)
            {
                options[i].SetActive(true);
                options[i].GetComponent<AnswerScript>().isCorrect = false;
                options[i].transform.GetChild(0).GetComponent<TMP_Text>().text = currentQnA[currentQuestion].Answers[i];

                if (currentQnA[currentQuestion].CorrectAnswer == i)
                {
                    options[i].GetComponent<AnswerScript>().isCorrect = true;
                }
            }
        }
        else if (level == 2)
        {
            for (int i = 0; i < 2; i++)
            {
                options[i].SetActive(true);
                options[i].GetComponent<AnswerScript>().isCorrect = false;
                options[i].transform.GetChild(0).GetComponent<TMP_Text>().text = currentQnA[currentQuestion].Answers[i];

                if (currentQnA[currentQuestion].CorrectAnswer == i)
                {
                    options[i].GetComponent<AnswerScript>().isCorrect = true;
                }
            }
        }
    }


    void generateQuestion()
    {
        if (currentQnA.Count > 0)
        {
            currentQuestion = Random.Range(0, currentQnA.Count);

            QuestionTxt.text = currentQnA[currentQuestion].Question;

            SetAnswers();
        }
        else
        {
            Debug.Log("No more questions in current level");
        }
    }
}
