using UnityEngine;

[System.Serializable]
public class WordQuestion
{
    public string Word;
    public Sprite AssociatedImage;
}
